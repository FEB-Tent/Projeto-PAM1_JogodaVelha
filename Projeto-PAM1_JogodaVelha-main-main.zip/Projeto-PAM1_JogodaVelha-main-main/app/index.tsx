import { Text, TouchableOpacity } from "react-native";

export default function index() {
  const nome = "DMC";

  return (
    <view>
      <center>
        {" "}
        <Text>Jogo da Velha</Text>
        <br></br>
        <Text>Vencedor</Text>
      </center>

      <view>
        <view>
          <TouchableOpacity>
            <text>BOTAO</text>
          </TouchableOpacity>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
        </view>

        <view>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
        </view>

        <view>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
          <TouchableOpacity>
            <text></text>
          </TouchableOpacity>
        </view>
      </view>
    </view>
  );
}
